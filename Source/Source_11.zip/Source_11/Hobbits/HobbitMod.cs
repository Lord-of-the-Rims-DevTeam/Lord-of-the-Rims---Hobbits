﻿using Verse;

namespace LordOfTheRims_Hobbits
{
    public class HobbitMod : Mod
    {
        public HobbitMod(ModContentPack content) : base(content)
        {
            
        }
    }
}